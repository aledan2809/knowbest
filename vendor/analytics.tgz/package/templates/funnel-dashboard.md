# Șablon — dashboard funnel in-app (`/admin/analytics`)

Al 4-lea strat de analytics: **funnel-ul de business din datele proprii ale aplicației**
(nu vizitatori anonimi, ci lead → acțiune → plată → venit). Nu e cod comun — fiecare
aplicație are alt model de date — dar forma e mereu aceeași. Copiază + adaptează.

**Implementare de referință (LIVE):** ave-platform
- API: `app/api/admin/analytics/route.ts` — guard admin + agregări Prisma
- UI: `app/(dashboard)/analytics/page.tsx` — KPI cards + funnel bars + serie zilnică (bare CSS, zero dependențe)
- Nav: item „Analytics" în sidebar-ul de admin

## Rețeta (per proiect, ~2-3h)

1. **Identifică cele 3-5 trepte de funnel din modelul tău de date.** Exemple:
   - AVE: `Audit` creat → status teaser → `AuditOrder` PAID
   - e-commerce: vizită → cont → coș → comandă plătită
   - SaaS: signup → onboarding done → subscripție activă
2. **API route** `GET /api/admin/analytics?days=30`, protejat cu guard-ul admin existent
   al proiectului (`requireAdmin` / rol / NextAuth). Întoarce:
   - `kpis`: totaluri + rate de conversie între trepte + venit (suma comenzilor plătite, minor units → unități)
   - `funnel[]`: `{ stage, count, pct }` — pct raportat la prima treaptă
   - `daily[]`: serie pe fereastră (`days` param, cap la 365) — creări/zi + plăți/zi + venit/zi
   - `byProduct[]` / `topX[]` / `recentPaid[]` — ce are sens per proiect
3. **Pagina client** în admin-ul existent: KPI cards (stilul proiectului), bare de funnel
   (div-uri cu width %), grafic zilnic din bare CSS (fără chart lib — vezi referința),
   tabel plăți recente. Selector 7/30/90 zile.
4. **Capcane văzute în practică:**
   - numără **entități distincte care au plătit** (`new Set(orders.map(o => o.parentId))`),
     nu comenzi — o entitate poate avea mai multe comenzi (dublează conversia).
   - banii se însumează din **minor units** (`amountCents`) și se formatează la afișare.
   - agregă în API (server), nu trimite rânduri brute în client.
   - `dynamic = 'force-dynamic'` pe route — cifrele nu se cache-uiesc.
5. **(opțional) leagă de Umami:** emite `trackEvent('checkout_started')` etc. din
   `@aledan/analytics` la treptele de funnel → vezi aceleași trepte și în Umami,
   pe lângă dashboard-ul intern.
