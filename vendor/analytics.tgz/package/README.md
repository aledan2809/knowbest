# @aledan/analytics

Kit de analytics pentru tot ecosistemul — extras din implementarea techbiz/AVE
(2026-07-01). Un proiect îl adoptă în ~15 minute și primește toate straturile:

| Strat | Ce dă | Cum |
|---|---|---|
| **Umami** (cookieless) | vizitatori, surse/UTM, țară, device — fără banner de consimțământ, date pe VPS-ul nostru | `<UmamiScript websiteId>` + provisioning |
| **GA4** (consent-gated) | standardul Google (reclame, atribuire) — pornește DOAR după Accept | `<CookieConsent gaId>` |
| **GoAccess** (per VPS) | adevărul brut din log-urile nginx, incl. boți | `scripts/goaccess-vps-setup.sh` — o dată per server |
| **Funnel in-app** | lead → acțiune → plată → venit, din datele aplicației | `templates/funnel-dashboard.md` (recipe) |

**Instanța centrală Umami** (una pentru toate proiectele, docker pe VPS1 :3050, PG16 local):
- `https://analytics.knowbest.ro` — alias neutru (default în lib)
- `https://analytics.techbiz.ae` — alias techbiz (site-urile AVE)
- Dashboard + creds: `Master/credentials/techbiz-analytics.env`

## Adopție — proiect Next.js (pașii standard)

```bash
# 1. provisionează site-ul în Umami (o dată) → primești websiteId
node scripts/provision-umami.mjs --name "etutor.ro" --domain etutor.ro

# 2. vendored tgz (L93/L241 — portabil pe VPS, fără sibling dir)
npm run build && npm pack   # → aledan-analytics-0.1.0.tgz
cp aledan-analytics-*.tgz <project>/vendor/analytics.tgz
# în <project>/package.json:  "@aledan/analytics": "file:vendor/analytics.tgz"
# în next.config:             transpilePackages: ['@aledan/analytics']
```

```tsx
// 3. în app/layout.tsx (root):
import { CookieConsent, UmamiScript } from '@aledan/analytics/react'
...
<body>
  {children}
  <UmamiScript websiteId="<websiteId>" />                {/* mereu, cookieless */}
  <CookieConsent gaId="G-XXXXXXX" privacyHref="/privacy" /> {/* GA4 doar după Accept */}
</body>
```

```
# 4. CSP-ul proiectului TREBUIE să permită originile (altfel zero date — lecția techbiz):
script-src  += https://analytics.knowbest.ro https://www.googletagmanager.com
connect-src += https://analytics.knowbest.ro https://www.googletagmanager.com
               https://www.google-analytics.com https://*.google-analytics.com
img-src     += https://www.google-analytics.com https://*.googletagmanager.com
# helper: GA4_CSP + umamiCsp() exportă exact listele astea.
```

## Consimțământ — 3 situații

1. **Proiect fără banner** → `<CookieConsent gaId>` (standalone, localStorage). Bilingv
   EN/RO automat (`?lang` → `<html lang>` → browser); copy/culori override prin props.
2. **Proiect integrat Legal Hub, fără banner de cookies** → aceeași componentă cu
   `adapter={legalHubAdapter({ endpoint: '/api/legal/consent' })}` — decizia se scrie
   ca ConsentRecord prin proxy-ul serverului tău (fail-soft: o eroare de rețea nu
   blochează vizitatorul).
3. **Proiect care ARE deja banner Legal Hub (knowbest, utilajhub…)** → NU monta
   `CookieConsent` (nu vrem două bannere). Cheamă `loadGA4('G-XXXX')` din calea de
   „Accept" a banner-ului existent + la load dacă decizia salvată e granted.

## Extra

- `trackEvent('nume', {date})` — evenimente custom în Umami (trepte de funnel, CTA).
- GA4 pe subdomeniile aceluiași domeniu: **un singur Measurement ID** (cookie partajat
  pe apex → o singură călătorie; filtrezi în GA după Hostname). Nu crea stream-uri separate.
- GoAccess: rulează scriptul o dată per VPS (VPS1 e făcut — 2026-07-01); salvează parola
  generată în `Master/credentials/`.
- Verificare onestă post-adopție: vizită cu browser real (UA normal, nu headless — Umami
  ignoră boții) → vezi hit-ul în Umami; Accept → `gtag/js` 200 + `/g/collect` 204 → GA4 Realtime.

## Dev

```bash
npm test        # vitest (16)
npm run build   # tsup CJS+ESM+dts → dist/ + dist/react/
```

Zero deps runtime; `react >=18` peer opțional (doar pentru `/react`).
