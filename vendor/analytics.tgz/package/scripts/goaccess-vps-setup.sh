#!/bin/bash
# GoAccess per-VPS setup — server-log analytics for every domain on one VPS.
# Run ONCE per VPS (as root). Idempotent-ish: re-running refreshes the pieces.
#
# What it does:
#   1. apt-install goaccess
#   2. adds a dedicated access_log per requested nginx vhost (surgical insert)
#   3. installs /usr/local/bin/goaccess-refresh.sh + a */2min cron
#   4. serves the HTML reports behind basic-auth at https://<serve_host>/_stats/
#
# Usage (edit the CONFIG block, then):  bash goaccess-vps-setup.sh
# Reference install: VPS1 (2026-07-01) for techbiz.ae + app.techbiz.ae.

set -euo pipefail

### CONFIG ####################################################################
DOMAINS=("example.com" "app.example.com")   # nginx vhost filenames in sites-enabled/
SERVE_VHOST="app.example.com"                # which vhost serves /_stats/
STATS_USER="stats"
STATS_PASS="$(openssl rand -hex 12)"         # printed at the end — save it!
TZ_REGION="Europe/Bucharest"
###############################################################################

OUT=/var/www/goaccess
DEBIAN_FRONTEND=noninteractive apt-get install -y goaccess

mkdir -p "$OUT" && chown www-data:www-data "$OUT"

# 1) per-domain access_log (added right after the first server_name = the 443 block)
for d in "${DOMAINS[@]}"; do
  f="/etc/nginx/sites-enabled/$d"
  [ -f "$f" ] || { echo "skip $d (no vhost)"; continue; }
  grep -q "/var/log/nginx/$d.access.log" "$f" && { echo "$d already logged"; continue; }
  cp "$f" "$f.bak-$(date +%F)-goaccess"
  python3 - "$f" "$d" <<'PYEOF'
import sys
path, logname = sys.argv[1], sys.argv[2]
lines = open(path).read().split('\n')
out, done = [], False
for ln in lines:
    out.append(ln)
    if not done and ln.strip().startswith('server_name'):
        indent = ln[:len(ln)-len(ln.lstrip())]
        out.append(f'{indent}access_log /var/log/nginx/{logname}.access.log;')
        done = True
open(path, 'w').write('\n'.join(out))
print('patched', path)
PYEOF
done

# 2) refresh script
cat > /usr/local/bin/goaccess-refresh.sh <<SH
#!/bin/bash
OUT=$OUT
gen(){
  local tmp=\$(mktemp); : > "\$tmp"
  for f in \$1; do [ -f "\$f" ] && cat "\$f" >> "\$tmp" 2>/dev/null; done
  for f in \$(ls \$1.1 2>/dev/null); do cat "\$f" >> "\$tmp" 2>/dev/null; done
  if [ -s "\$tmp" ]; then
    goaccess "\$tmp" -o "\$OUT/\$2" --log-format=COMBINED --html-report-title="\$3" --tz=$TZ_REGION 2>/dev/null
  else
    echo "<html><body style='font-family:sans-serif;padding:2rem'><h2>\$3</h2><p>No data yet.</p></body></html>" > "\$OUT/\$2"
  fi
  rm -f "\$tmp"
}
gen '/var/log/nginx/access.log' overview.html 'overview (all vhosts)'
$(for d in "${DOMAINS[@]}"; do echo "gen '/var/log/nginx/$d.access.log' $d.html '$d'"; done)
{
  echo "<html><head><meta charset=utf-8><title>Analytics</title></head><body style='font-family:sans-serif;max-width:640px;margin:3rem auto'><h1>Server analytics</h1><ul style='font-size:18px;line-height:2'>"
$(for d in "${DOMAINS[@]}"; do echo "  echo \"<li><a href='$d.html'>$d</a></li>\""; done)
  echo "<li><a href='overview.html'>Overview (all vhosts)</a></li></ul></body></html>"
} > "\$OUT/index.html"
chown -R www-data:www-data "\$OUT"
SH
chmod +x /usr/local/bin/goaccess-refresh.sh
( crontab -l 2>/dev/null | grep -v goaccess-refresh; echo '*/2 * * * * /usr/local/bin/goaccess-refresh.sh' ) | crontab -

# 3) basic-auth + serving location on the chosen vhost
printf '%s:%s\n' "$STATS_USER" "$(openssl passwd -apr1 "$STATS_PASS")" > /etc/nginx/.htpasswd-stats
chmod 640 /etc/nginx/.htpasswd-stats && chown root:www-data /etc/nginx/.htpasswd-stats
python3 - "/etc/nginx/sites-enabled/$SERVE_VHOST" <<'PYEOF'
import sys
p = sys.argv[1]
s = open(p).read()
if '/_stats/' not in s:
    loc = '''    location /_stats/ {
        auth_basic "server analytics";
        auth_basic_user_file /etc/nginx/.htpasswd-stats;
        alias /var/www/goaccess/;
        index index.html;
        autoindex off;
    }

    location / {'''
    s = s.replace('    location / {', loc, 1)
    open(p, 'w').write(s)
    print('added /_stats/ to', p)
else:
    print('/_stats/ already present')
PYEOF

nginx -t && systemctl reload nginx
/usr/local/bin/goaccess-refresh.sh

echo "==============================================="
echo "GoAccess live: https://$SERVE_VHOST/_stats/"
echo "user: $STATS_USER"
echo "pass: $STATS_PASS   <-- SAVE THIS (Master/credentials/)"
